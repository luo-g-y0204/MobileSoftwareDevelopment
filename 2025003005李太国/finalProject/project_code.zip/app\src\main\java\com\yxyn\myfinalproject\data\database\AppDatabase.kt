package com.yxyn.myfinalproject.data.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.yxyn.myfinalproject.data.dao.PomodoroSessionDao
import com.yxyn.myfinalproject.data.dao.TaskDao
import com.yxyn.myfinalproject.data.entity.PomodoroSessionEntity
import com.yxyn.myfinalproject.data.entity.TaskEntity

@Database(
    entities = [PomodoroSessionEntity::class, TaskEntity::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun pomodoroSessionDao(): PomodoroSessionDao
    abstract fun taskDao(): TaskDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "pomodoro_database"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
