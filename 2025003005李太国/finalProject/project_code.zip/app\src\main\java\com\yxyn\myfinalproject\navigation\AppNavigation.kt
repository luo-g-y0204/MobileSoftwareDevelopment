package com.yxyn.myfinalproject.navigation

import androidx.compose.runtime.Composable
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.yxyn.myfinalproject.data.database.AppDatabase
import com.yxyn.myfinalproject.data.repository.PomodoroRepository
import com.yxyn.myfinalproject.datastore.UserPreferencesRepository
import com.yxyn.myfinalproject.ui.screens.HistoryScreen
import com.yxyn.myfinalproject.ui.screens.SettingsScreen
import com.yxyn.myfinalproject.ui.screens.TaskListScreen
import com.yxyn.myfinalproject.ui.screens.TimerScreen
import com.yxyn.myfinalproject.viewmodel.HistoryViewModel
import com.yxyn.myfinalproject.viewmodel.TaskViewModel
import com.yxyn.myfinalproject.viewmodel.TimerViewModel
import android.content.Context

object Routes {
    const val TIMER = "timer"
    const val HISTORY = "history"
    const val TASK_LIST = "task_list"
    const val SETTINGS = "settings"
}

@Composable
fun AppNavigation(context: Context) {
    val navController = rememberNavController()

    // Shared dependencies
    val database = AppDatabase.getInstance(context)
    val repository = PomodoroRepository(
        database.pomodoroSessionDao(),
        database.taskDao()
    )
    val preferences = UserPreferencesRepository(context)

    NavHost(
        navController = navController,
        startDestination = Routes.TIMER
    ) {
        composable(Routes.TIMER) {
            val viewModel: TimerViewModel = viewModel(
                factory = TimerViewModel.Factory(repository, preferences)
            )
            TimerScreen(
                viewModel = viewModel,
                onNavigateToHistory = { navController.navigate(Routes.HISTORY) },
                onNavigateToTasks = { navController.navigate(Routes.TASK_LIST) },
                onNavigateToSettings = { navController.navigate(Routes.SETTINGS) }
            )
        }

        composable(Routes.HISTORY) {
            val viewModel: HistoryViewModel = viewModel(
                factory = HistoryViewModel.Factory(repository)
            )
            HistoryScreen(
                viewModel = viewModel,
                onNavigateBack = { navController.popBackStack() }
            )
        }

        composable(Routes.TASK_LIST) {
            val viewModel: TaskViewModel = viewModel(
                factory = TaskViewModel.Factory(repository)
            )
            TaskListScreen(
                viewModel = viewModel,
                onNavigateBack = { navController.popBackStack() }
            )
        }

        composable(Routes.SETTINGS) {
            SettingsScreen(
                preferences = preferences,
                onNavigateBack = { navController.popBackStack() }
            )
        }
    }
}
