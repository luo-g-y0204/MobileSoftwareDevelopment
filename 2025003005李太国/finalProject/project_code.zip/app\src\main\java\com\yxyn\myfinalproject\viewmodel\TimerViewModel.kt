package com.yxyn.myfinalproject.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.yxyn.myfinalproject.data.entity.PomodoroSessionEntity
import com.yxyn.myfinalproject.data.entity.TaskEntity
import com.yxyn.myfinalproject.data.repository.PomodoroRepository
import com.yxyn.myfinalproject.datastore.UserPreferencesRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class TimerViewModel(
    private val repository: PomodoroRepository,
    private val preferences: UserPreferencesRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(TimerUiState())
    val uiState: StateFlow<TimerUiState> = _uiState.asStateFlow()

    private var timerJob: Job? = null
    private var workDuration = UserPreferencesRepository.DEFAULT_WORK_DURATION * 60
    private var shortBreakDuration = UserPreferencesRepository.DEFAULT_SHORT_BREAK_DURATION * 60
    private var longBreakDuration = UserPreferencesRepository.DEFAULT_LONG_BREAK_DURATION * 60
    private var longBreakInterval = UserPreferencesRepository.DEFAULT_LONG_BREAK_INTERVAL
    private var sessionStartTime: Long = 0L

    init {
        loadPreferences()
        loadTasks()
        observeSessions()
    }

    private fun loadPreferences() {
        viewModelScope.launch {
            preferences.workDuration.collectLatest { minutes ->
                workDuration = minutes * 60
                if (_uiState.value.timerStatus == TimerStatus.IDLE && _uiState.value.sessionType == SessionType.WORK) {
                    _uiState.update { it.copy(remainingSeconds = workDuration, totalSeconds = workDuration) }
                }
            }
        }
        viewModelScope.launch {
            preferences.shortBreakDuration.collectLatest { minutes ->
                shortBreakDuration = minutes * 60
            }
        }
        viewModelScope.launch {
            preferences.longBreakDuration.collectLatest { minutes ->
                longBreakDuration = minutes * 60
            }
        }
        viewModelScope.launch {
            preferences.longBreakInterval.collectLatest { interval ->
                _uiState.update { it.copy(sessionGoal = interval) }
                longBreakInterval = interval
            }
        }
        viewModelScope.launch {
            preferences.currentTaskId.collectLatest { taskId ->
                if (taskId != null) {
                    val task = repository.getTaskById(taskId)
                    _uiState.update { it.copy(currentTask = task) }
                } else {
                    _uiState.update { it.copy(currentTask = null) }
                }
            }
        }
        // Initialize timer display
        _uiState.update {
            it.copy(remainingSeconds = workDuration, totalSeconds = workDuration)
        }
    }

    private fun loadTasks() {
        viewModelScope.launch {
            _uiState.update { it.copy(isTasksLoading = true) }
            try {
                repository.getActiveTasks().collectLatest { tasks ->
                    _uiState.update { it.copy(tasks = tasks, isTasksLoading = false) }
                }
            } catch (e: Exception) {
                _uiState.update { it.copy(isTasksLoading = false, errorMessage = "加载任务失败: ${e.message}") }
            }
        }
    }

    private fun observeSessions() {
        viewModelScope.launch {
            combine(
                repository.getTotalCompletedWorkSessions(),
                repository.getTodayCompletedWorkSessions(),
                repository.getTotalWorkSeconds()
            ) { total, today, totalSec ->
                Triple(total, today, totalSec)
            }.collectLatest { (total, today, totalSec) ->
                _uiState.update {
                    it.copy(
                        completedSessions = total,
                        todaySessions = today,
                        totalWorkMinutes = (totalSec ?: 0) / 60
                    )
                }
            }
        }
    }

    fun selectTask(task: TaskEntity) {
        viewModelScope.launch {
            preferences.setCurrentTaskId(task.id)
            _uiState.update { it.copy(currentTask = task) }
        }
    }

    fun clearCurrentTask() {
        viewModelScope.launch {
            preferences.setCurrentTaskId(null)
            _uiState.update { it.copy(currentTask = null) }
        }
    }

    fun startTimer() {
        if (_uiState.value.timerStatus == TimerStatus.IDLE) {
            sessionStartTime = System.currentTimeMillis()
            // Reset timer based on session type
            val durationSeconds = when (_uiState.value.sessionType) {
                SessionType.WORK -> workDuration
                SessionType.SHORT_BREAK -> shortBreakDuration
                SessionType.LONG_BREAK -> longBreakDuration
            }
            _uiState.update {
                it.copy(
                    timerStatus = TimerStatus.RUNNING,
                    remainingSeconds = durationSeconds,
                    totalSeconds = durationSeconds
                )
            }
        } else if (_uiState.value.timerStatus == TimerStatus.PAUSED) {
            _uiState.update { it.copy(timerStatus = TimerStatus.RUNNING) }
        }
        startCountdown()
    }

    fun pauseTimer() {
        _uiState.update { it.copy(timerStatus = TimerStatus.PAUSED) }
        timerJob?.cancel()
    }

    fun resetTimer() {
        timerJob?.cancel()
        val durationSeconds = when (_uiState.value.sessionType) {
            SessionType.WORK -> workDuration
            SessionType.SHORT_BREAK -> shortBreakDuration
            SessionType.LONG_BREAK -> longBreakDuration
        }
        _uiState.update {
            it.copy(
                timerStatus = TimerStatus.IDLE,
                remainingSeconds = durationSeconds,
                totalSeconds = durationSeconds
            )
        }
    }

    fun skipSession() {
        timerJob?.cancel()
        onSessionComplete(wasSkipped = true)
    }

    private fun startCountdown() {
        timerJob?.cancel()
        timerJob = viewModelScope.launch {
            while (_uiState.value.remainingSeconds > 0) {
                delay(1000L)
                if (_uiState.value.timerStatus == TimerStatus.RUNNING) {
                    _uiState.update { it.copy(remainingSeconds = it.remainingSeconds - 1) }
                }
            }
            onSessionComplete()
        }
    }

    private fun onSessionComplete(wasSkipped: Boolean = false) {
        viewModelScope.launch {
            val currentState = _uiState.value
            val sessionType = currentState.sessionType
            val endTime = System.currentTimeMillis()
            val durationSeconds = if (wasSkipped) {
                ((endTime - sessionStartTime) / 1000).toInt().coerceAtLeast(0)
            } else {
                currentState.totalSeconds
            }

            // Save completed session
            val session = PomodoroSessionEntity(
                taskId = currentState.currentTask?.id,
                startTime = sessionStartTime,
                endTime = endTime,
                durationSeconds = durationSeconds,
                type = sessionType.name.lowercase(),
                isCompleted = !wasSkipped,
                note = if (wasSkipped) "跳过" else ""
            )
            repository.insertSession(session)

            // Increment task completed pomodoros if work session completed
            if (sessionType == SessionType.WORK && !wasSkipped) {
                currentState.currentTask?.let { task ->
                    repository.incrementCompletedPomodoros(task.id)
                }
            }

            // Determine next session type
            if (sessionType == SessionType.WORK) {
                val nextType = if ((currentState.completedSessions + 1) % longBreakInterval == 0 &&
                    currentState.completedSessions + 1 > 0
                ) {
                    SessionType.LONG_BREAK
                } else {
                    SessionType.SHORT_BREAK
                }
                _uiState.update {
                    it.copy(
                        timerStatus = TimerStatus.IDLE,
                        sessionType = nextType,
                        remainingSeconds = if (nextType == SessionType.LONG_BREAK) longBreakDuration else shortBreakDuration,
                        totalSeconds = if (nextType == SessionType.LONG_BREAK) longBreakDuration else shortBreakDuration
                    )
                }
                // Check auto-start break preference
                val autoStart = preferences.autoStartBreak.first()
                if (autoStart) {
                    sessionStartTime = System.currentTimeMillis()
                    _uiState.update { it.copy(timerStatus = TimerStatus.RUNNING) }
                    startCountdown()
                }
            } else {
                // Break session ended, switch to work
                _uiState.update {
                    it.copy(
                        timerStatus = TimerStatus.IDLE,
                        sessionType = SessionType.WORK,
                        remainingSeconds = workDuration,
                        totalSeconds = workDuration
                    )
                }
                val autoStart = preferences.autoStartWork.first()
                if (autoStart) {
                    sessionStartTime = System.currentTimeMillis()
                    _uiState.update { it.copy(timerStatus = TimerStatus.RUNNING) }
                    startCountdown()
                }
            }

            // Refresh sessions count
            loadTasks()
        }
    }

    fun loadQuote() {
        viewModelScope.launch {
            _uiState.update { it.copy(quoteState = it.quoteState.copy(isLoading = true, error = null)) }
            val result = repository.fetchMotivationalQuote()
            result.fold(
                onSuccess = { dto ->
                    _uiState.update {
                        it.copy(
                            quoteState = QuoteState(
                                content = dto.content,
                                author = dto.author,
                                isLoading = false
                            )
                        )
                    }
                },
                onFailure = { e ->
                    // Network failed, use default quote
                    _uiState.update {
                        it.copy(
                            quoteState = QuoteState(
                                content = "专注是效率的灵魂，坚持是成功的钥匙。",
                                author = "番茄钟",
                                isLoading = false
                            )
                        )
                    }
                }
            )
        }
    }

    fun clearError() {
        _uiState.update { it.copy(errorMessage = null) }
    }

    class Factory(
        private val repository: PomodoroRepository,
        private val preferences: UserPreferencesRepository
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            if (modelClass.isAssignableFrom(TimerViewModel::class.java)) {
                return TimerViewModel(repository, preferences) as T
            }
            throw IllegalArgumentException("Unknown ViewModel class: ${modelClass.name}")
        }
    }
}
