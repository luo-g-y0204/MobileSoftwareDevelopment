package com.yxyn.myfinalproject.viewmodel

import com.yxyn.myfinalproject.data.entity.TaskEntity
import com.yxyn.myfinalproject.data.network.QuoteDto

// Timer state
enum class TimerStatus {
    IDLE,
    RUNNING,
    PAUSED
}

enum class SessionType {
    WORK,
    SHORT_BREAK,
    LONG_BREAK
}

data class QuoteState(
    val content: String = "",
    val author: String = "",
    val isLoading: Boolean = false,
    val error: String? = null
)

data class TimerUiState(
    val timerStatus: TimerStatus = TimerStatus.IDLE,
    val sessionType: SessionType = SessionType.WORK,
    val remainingSeconds: Int = 0,
    val totalSeconds: Int = 0,
    val completedSessions: Int = 0,
    val sessionGoal: Int = 4, // long break interval
    val currentTask: TaskEntity? = null,
    val tasks: List<TaskEntity> = emptyList(),
    val quoteState: QuoteState = QuoteState(),
    val todaySessions: Int = 0,
    val totalWorkMinutes: Int = 0,
    val isTasksLoading: Boolean = false,
    val errorMessage: String? = null
)
