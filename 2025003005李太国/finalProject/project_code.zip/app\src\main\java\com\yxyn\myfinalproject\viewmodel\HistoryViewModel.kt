package com.yxyn.myfinalproject.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.yxyn.myfinalproject.data.repository.PomodoroRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class HistoryViewModel(
    private val repository: PomodoroRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow<HistoryUiState>(HistoryUiState.Loading)
    val uiState: StateFlow<HistoryUiState> = _uiState.asStateFlow()

    init {
        loadHistory()
    }

    fun loadHistory() {
        viewModelScope.launch {
            _uiState.value = HistoryUiState.Loading
            try {
                combineSessions()
            } catch (e: Exception) {
                _uiState.value = HistoryUiState.Empty
            }
        }
    }

    private suspend fun combineSessions() {
        // Get one-shot task snapshot
        val taskSnapshot = try {
            repository.getAllTasks().first()
        } catch (e: Exception) {
            emptyList()
        }
        val taskMap = taskSnapshot.associate { it.id to it.title }

        repository.getAllSessions().collectLatest { sessions ->
            if (sessions.isEmpty()) {
                _uiState.value = HistoryUiState.Empty
                return@collectLatest
            }

            val displayItems = sessions.map { session ->
                SessionDisplayItem(
                    id = session.id,
                    type = session.type,
                    typeLabel = when (session.type) {
                        "work" -> "🍅 工作"
                        "short_break" -> "☕ 短休息"
                        "long_break" -> "🌴 长休息"
                        else -> session.type
                    },
                    durationSeconds = session.durationSeconds,
                    startTime = session.startTime,
                    endTime = session.endTime,
                    isCompleted = session.isCompleted,
                    taskTitle = session.taskId?.let { taskMap[it] },
                    note = session.note
                )
            }

            val totalWorkSeconds = sessions
                .filter { it.type == "work" && it.isCompleted }
                .sumOf { it.durationSeconds }

            val cal = java.util.Calendar.getInstance()
            cal.set(java.util.Calendar.HOUR_OF_DAY, 0)
            cal.set(java.util.Calendar.MINUTE, 0)
            cal.set(java.util.Calendar.SECOND, 0)
            cal.set(java.util.Calendar.MILLISECOND, 0)
            val todayStart = cal.timeInMillis

            val todaySessions = sessions.count {
                it.startTime >= todayStart && it.type == "work" && it.isCompleted
            }

            _uiState.value = HistoryUiState.Success(
                sessions = displayItems,
                totalWorkMinutes = totalWorkSeconds / 60,
                totalSessions = sessions.count { it.type == "work" && it.isCompleted },
                todaySessions = todaySessions
            )
        }
    }

    class Factory(
        private val repository: PomodoroRepository
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            if (modelClass.isAssignableFrom(HistoryViewModel::class.java)) {
                return HistoryViewModel(repository) as T
            }
            throw IllegalArgumentException("Unknown ViewModel class: ${modelClass.name}")
        }
    }
}
