package com.yxyn.myfinalproject.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import kotlinx.coroutines.launch
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.yxyn.myfinalproject.datastore.UserPreferencesRepository
import kotlinx.coroutines.flow.first
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    preferences: UserPreferencesRepository,
    onNavigateBack: () -> Unit
) {
    val workDuration by preferences.workDuration.collectAsState(initial = UserPreferencesRepository.DEFAULT_WORK_DURATION)
    val shortBreakDuration by preferences.shortBreakDuration.collectAsState(initial = UserPreferencesRepository.DEFAULT_SHORT_BREAK_DURATION)
    val longBreakDuration by preferences.longBreakDuration.collectAsState(initial = UserPreferencesRepository.DEFAULT_LONG_BREAK_DURATION)
    val longBreakInterval by preferences.longBreakInterval.collectAsState(initial = UserPreferencesRepository.DEFAULT_LONG_BREAK_INTERVAL)
    val autoStartBreak by preferences.autoStartBreak.collectAsState(initial = false)
    val autoStartWork by preferences.autoStartWork.collectAsState(initial = false)

    var showSaveSuccess by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("⚙ 设置") },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "返回")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Timer durations
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                ),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        "⏱ 时长设置",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(16.dp))

                    DurationSlider(
                        label = "工作时长",
                        value = workDuration,
                        valueRange = 5f..60f,
                        onValueChange = { scope.launch { preferences.setWorkDuration(it) } },
                        unit = "分钟"
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    DurationSlider(
                        label = "短休息时长",
                        value = shortBreakDuration,
                        valueRange = 1f..30f,
                        onValueChange = { scope.launch { preferences.setShortBreakDuration(it) } },
                        unit = "分钟"
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    DurationSlider(
                        label = "长休息时长",
                        value = longBreakDuration,
                        valueRange = 5f..60f,
                        onValueChange = { scope.launch { preferences.setLongBreakDuration(it) } },
                        unit = "分钟"
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    DurationSlider(
                        label = "长休息间隔",
                        value = longBreakInterval,
                        valueRange = 2f..8f,
                        onValueChange = { scope.launch { preferences.setLongBreakInterval(it) } },
                        unit = "个番茄",
                        stepSize = 1
                    )
                }
            }

            // Auto start options
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                ),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        "🔄 自动切换",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    SwitchSetting(
                        label = "工作时间结束后自动开始休息",
                        checked = autoStartBreak,
                        onCheckedChange = { scope.launch { preferences.setAutoStartBreak(it) } }
                    )

                    SwitchSetting(
                        label = "休息结束后自动开始工作",
                        checked = autoStartWork,
                        onCheckedChange = { scope.launch { preferences.setAutoStartWork(it) } }
                    )
                }
            }

            // About section
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                ),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        "📱 关于",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        "番茄钟 - Pomodoro Timer",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Text(
                        "基于番茄工作法，帮助您提高专注力和工作效率。\n25分钟专注工作，5分钟短暂休息，每4个番茄后进行一次长休息。",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        "API 数据来源: Quotable API (api.quotable.io)",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                    )
                }
            }
        }
    }
}

@Composable
fun DurationSlider(
    label: String,
    value: Int,
    valueRange: ClosedFloatingPointRange<Float>,
    onValueChange: (Int) -> Unit,
    unit: String,
    stepSize: Int = 1
) {
    Column {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                label,
                style = MaterialTheme.typography.bodyMedium
            )
            Text(
                "$value $unit",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
        }
        Slider(
            value = value.toFloat(),
            onValueChange = {
                val stepped = (it / stepSize).roundToInt() * stepSize
                onValueChange(stepped.coerceIn(valueRange.start.toInt(), valueRange.endInclusive.toInt()))
            },
            valueRange = valueRange,
            steps = ((valueRange.endInclusive - valueRange.start) / stepSize).toInt() - 1,
            colors = SliderDefaults.colors(
                thumbColor = MaterialTheme.colorScheme.primary,
                activeTrackColor = MaterialTheme.colorScheme.primary
            )
        )
    }
}

@Composable
fun SwitchSetting(
    label: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            label,
            style = MaterialTheme.typography.bodyMedium,
            modifier = Modifier.weight(1f)
        )
        Spacer(modifier = Modifier.width(16.dp))
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange
        )
    }
}
