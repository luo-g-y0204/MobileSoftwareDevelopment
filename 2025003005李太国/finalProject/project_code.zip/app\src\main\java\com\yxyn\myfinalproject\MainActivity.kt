package com.yxyn.myfinalproject

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.yxyn.myfinalproject.navigation.AppNavigation
import com.yxyn.myfinalproject.ui.theme.MyfinalProjectTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyfinalProjectTheme {
                AppNavigation(context = applicationContext)
            }
        }
    }
}
