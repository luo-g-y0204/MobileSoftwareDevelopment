package com.yxyn.myfinalproject.data.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.yxyn.myfinalproject.data.entity.PomodoroSessionEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface PomodoroSessionDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(session: PomodoroSessionEntity): Long

    @Update
    suspend fun update(session: PomodoroSessionEntity)

    @Delete
    suspend fun delete(session: PomodoroSessionEntity)

    @Query("SELECT * FROM pomodoro_sessions ORDER BY start_time DESC")
    fun getAllSessions(): Flow<List<PomodoroSessionEntity>>

    @Query("SELECT * FROM pomodoro_sessions WHERE task_id = :taskId ORDER BY start_time DESC")
    fun getSessionsByTaskId(taskId: Long): Flow<List<PomodoroSessionEntity>>

    @Query("SELECT * FROM pomodoro_sessions WHERE type = :type ORDER BY start_time DESC")
    fun getSessionsByType(type: String): Flow<List<PomodoroSessionEntity>>

    @Query("SELECT COUNT(*) FROM pomodoro_sessions WHERE type = 'work' AND is_completed = 1")
    fun getTotalCompletedWorkSessions(): Flow<Int>

    @Query("SELECT COUNT(*) FROM pomodoro_sessions WHERE type = 'work' AND date(start_time / 1000, 'unixepoch') = date('now') AND is_completed = 1")
    fun getTodayCompletedWorkSessions(): Flow<Int>

    @Query("SELECT SUM(duration_seconds) FROM pomodoro_sessions WHERE type = 'work' AND is_completed = 1")
    fun getTotalWorkSeconds(): Flow<Int?>

    @Query("DELETE FROM pomodoro_sessions")
    suspend fun deleteAll()
}
