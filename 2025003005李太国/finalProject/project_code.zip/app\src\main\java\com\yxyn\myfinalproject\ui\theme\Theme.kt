package com.yxyn.myfinalproject.ui.theme

import android.app.Activity
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val LightColorScheme = lightColorScheme(
    primary = TomatoLightPrimary,
    onPrimary = TomatoLightOnPrimary,
    primaryContainer = TomatoLightPrimaryContainer,
    onPrimaryContainer = TomatoLightOnPrimaryContainer,
    secondary = TomatoLightSecondary,
    onSecondary = TomatoLightOnSecondary,
    secondaryContainer = TomatoLightSecondaryContainer,
    onSecondaryContainer = TomatoLightOnSecondaryContainer,
    background = TomatoLightBackground,
    onBackground = TomatoLightOnBackground,
    surface = TomatoLightSurface,
    onSurface = TomatoLightOnSurface,
    surfaceVariant = TomatoLightSurfaceVariant,
    onSurfaceVariant = TomatoLightOnSurfaceVariant
)

private val DarkColorScheme = darkColorScheme(
    primary = TomatoDarkPrimary,
    onPrimary = TomatoDarkOnPrimary,
    primaryContainer = TomatoDarkPrimaryContainer,
    onPrimaryContainer = TomatoDarkOnPrimaryContainer,
    secondary = TomatoDarkSecondary,
    onSecondary = TomatoDarkOnSecondary,
    secondaryContainer = TomatoDarkSecondaryContainer,
    onSecondaryContainer = TomatoDarkOnSecondaryContainer,
    background = TomatoDarkBackground,
    onBackground = TomatoDarkOnBackground,
    surface = TomatoDarkSurface,
    onSurface = TomatoDarkOnSurface,
    surfaceVariant = TomatoDarkSurfaceVariant,
    onSurfaceVariant = TomatoDarkOnSurfaceVariant
)

@Composable
fun MyfinalProjectTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = true,
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = colorScheme.surface.toArgb()
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = !darkTheme
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = AppTypography,
        content = content
    )
}
