package com.yxyn.myfinalproject.ui.theme

import androidx.compose.ui.graphics.Color

// 番茄红主题 - Light Mode
val TomatoRed = Color(0xFFE53935)
val TomatoRedDark = Color(0xFFC62828)
val TomatoRedLight = Color(0xFFFFCDD2)
val GreenFinish = Color(0xFF4CAF50)
val GreenFinishDark = Color(0xFF388E3C)
val OrangeAccent = Color(0xFFFF9800)
val OrangeDark = Color(0xFFF57C00)
val BlueBreak = Color(0xFF2196F3)

// Light Theme
val TomatoLightPrimary = Color(0xFFD32F2F)
val TomatoLightOnPrimary = Color(0xFFFFFFFF)
val TomatoLightPrimaryContainer = Color(0xFFFFDAD6)
val TomatoLightOnPrimaryContainer = Color(0xFF410005)
val TomatoLightSecondary = Color(0xFF775653)
val TomatoLightOnSecondary = Color(0xFFFFFFFF)
val TomatoLightSecondaryContainer = Color(0xFFFFDAD6)
val TomatoLightOnSecondaryContainer = Color(0xFF2C1513)
val TomatoLightBackground = Color(0xFFFFF8F7)
val TomatoLightOnBackground = Color(0xFF221917)
val TomatoLightSurface = Color(0xFFFFF8F7)
val TomatoLightOnSurface = Color(0xFF221917)
val TomatoLightSurfaceVariant = Color(0xFFF5DDDA)
val TomatoLightOnSurfaceVariant = Color(0xFF534341)

// Dark Theme
val TomatoDarkPrimary = Color(0xFFFFB4AB)
val TomatoDarkOnPrimary = Color(0xFF690007)
val TomatoDarkPrimaryContainer = Color(0xFF930013)
val TomatoDarkOnPrimaryContainer = Color(0xFFFFDAD6)
val TomatoDarkSecondary = Color(0xFFE7BDB8)
val TomatoDarkOnSecondary = Color(0xFF442927)
val TomatoDarkSecondaryContainer = Color(0xFF5D3F3C)
val TomatoDarkOnSecondaryContainer = Color(0xFFFFDAD6)
val TomatoDarkBackground = Color(0xFF1A1110)
val TomatoDarkOnBackground = Color(0xFFF0DFDD)
val TomatoDarkSurface = Color(0xFF1A1110)
val TomatoDarkOnSurface = Color(0xFFF0DFDD)
val TomatoDarkSurfaceVariant = Color(0xFF534341)
val TomatoDarkOnSurfaceVariant = Color(0xFFD8C2BF)
