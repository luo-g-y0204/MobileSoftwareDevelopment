package com.yxyn.myfinalproject.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.yxyn.myfinalproject.data.entity.TaskEntity
import com.yxyn.myfinalproject.data.repository.PomodoroRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

sealed interface TaskListUiState {
    data object Loading : TaskListUiState
    data class Success(val tasks: List<TaskEntity>) : TaskListUiState
    data object Empty : TaskListUiState
    data class Error(val message: String) : TaskListUiState
}

class TaskViewModel(
    private val repository: PomodoroRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow<TaskListUiState>(TaskListUiState.Loading)
    val uiState: StateFlow<TaskListUiState> = _uiState.asStateFlow()

    init {
        loadTasks()
    }

    fun loadTasks() {
        viewModelScope.launch {
            _uiState.value = TaskListUiState.Loading
            try {
                repository.getAllTasks().collectLatest { tasks ->
                    _uiState.value = if (tasks.isEmpty()) {
                        TaskListUiState.Empty
                    } else {
                        TaskListUiState.Success(tasks)
                    }
                }
            } catch (e: Exception) {
                _uiState.value = TaskListUiState.Error("加载任务失败: ${e.message}")
            }
        }
    }

    fun searchTasks(query: String) {
        viewModelScope.launch {
            _uiState.value = TaskListUiState.Loading
            try {
                if (query.isBlank()) {
                    repository.getAllTasks().collectLatest { tasks ->
                        _uiState.value = if (tasks.isEmpty()) {
                            TaskListUiState.Empty
                        } else {
                            TaskListUiState.Success(tasks)
                        }
                    }
                } else {
                    repository.searchTasks(query).collectLatest { tasks ->
                        _uiState.value = if (tasks.isEmpty()) {
                            TaskListUiState.Empty
                        } else {
                            TaskListUiState.Success(tasks)
                        }
                    }
                }
            } catch (e: Exception) {
                _uiState.value = TaskListUiState.Error("搜索失败: ${e.message}")
            }
        }
    }

    fun addTask(title: String, description: String, estimatedPomodoros: Int) {
        viewModelScope.launch {
            try {
                val task = TaskEntity(
                    title = title.trim(),
                    description = description.trim(),
                    estimatedPomodoros = estimatedPomodoros
                )
                repository.insertTask(task)
            } catch (e: Exception) {
                _uiState.value = TaskListUiState.Error("添加任务失败: ${e.message}")
            }
        }
    }

    fun updateTask(task: TaskEntity) {
        viewModelScope.launch {
            try {
                repository.updateTask(task.copy(updatedAt = System.currentTimeMillis()))
            } catch (e: Exception) {
                _uiState.value = TaskListUiState.Error("更新任务失败: ${e.message}")
            }
        }
    }

    fun toggleTaskActive(task: TaskEntity) {
        viewModelScope.launch {
            try {
                repository.updateTask(
                    task.copy(
                        isActive = !task.isActive,
                        updatedAt = System.currentTimeMillis()
                    )
                )
            } catch (e: Exception) {
                _uiState.value = TaskListUiState.Error("更新任务失败: ${e.message}")
            }
        }
    }

    fun deleteTask(task: TaskEntity) {
        viewModelScope.launch {
            try {
                repository.deleteTask(task)
            } catch (e: Exception) {
                _uiState.value = TaskListUiState.Error("删除任务失败: ${e.message}")
            }
        }
    }

    class Factory(
        private val repository: PomodoroRepository
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            if (modelClass.isAssignableFrom(TaskViewModel::class.java)) {
                return TaskViewModel(repository) as T
            }
            throw IllegalArgumentException("Unknown ViewModel class: ${modelClass.name}")
        }
    }
}
