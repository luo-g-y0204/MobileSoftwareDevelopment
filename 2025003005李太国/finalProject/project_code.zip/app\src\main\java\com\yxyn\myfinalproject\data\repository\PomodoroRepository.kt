package com.yxyn.myfinalproject.data.repository

import com.yxyn.myfinalproject.data.dao.PomodoroSessionDao
import com.yxyn.myfinalproject.data.dao.TaskDao
import com.yxyn.myfinalproject.data.entity.PomodoroSessionEntity
import com.yxyn.myfinalproject.data.entity.TaskEntity
import com.yxyn.myfinalproject.data.network.NetworkDataSource
import com.yxyn.myfinalproject.data.network.QuoteDto
import kotlinx.coroutines.flow.Flow

class PomodoroRepository(
    private val sessionDao: PomodoroSessionDao,
    private val taskDao: TaskDao
) {
    // Session operations
    fun getAllSessions(): Flow<List<PomodoroSessionEntity>> = sessionDao.getAllSessions()

    fun getSessionsByTaskId(taskId: Long): Flow<List<PomodoroSessionEntity>> =
        sessionDao.getSessionsByTaskId(taskId)

    fun getSessionsByType(type: String): Flow<List<PomodoroSessionEntity>> =
        sessionDao.getSessionsByType(type)

    fun getTotalCompletedWorkSessions(): Flow<Int> =
        sessionDao.getTotalCompletedWorkSessions()

    fun getTodayCompletedWorkSessions(): Flow<Int> =
        sessionDao.getTodayCompletedWorkSessions()

    fun getTotalWorkSeconds(): Flow<Int?> =
        sessionDao.getTotalWorkSeconds()

    suspend fun insertSession(session: PomodoroSessionEntity): Long =
        sessionDao.insert(session)

    suspend fun updateSession(session: PomodoroSessionEntity) =
        sessionDao.update(session)

    suspend fun deleteSession(session: PomodoroSessionEntity) =
        sessionDao.delete(session)

    suspend fun deleteAllSessions() = sessionDao.deleteAll()

    // Task operations
    fun getAllTasks(): Flow<List<TaskEntity>> = taskDao.getAllTasks()

    fun getActiveTasks(): Flow<List<TaskEntity>> = taskDao.getActiveTasks()

    fun searchTasks(query: String): Flow<List<TaskEntity>> = taskDao.searchTasks(query)

    suspend fun getTaskById(taskId: Long): TaskEntity? = taskDao.getTaskById(taskId)

    suspend fun insertTask(task: TaskEntity): Long = taskDao.insert(task)

    suspend fun updateTask(task: TaskEntity) = taskDao.update(task)

    suspend fun deleteTask(task: TaskEntity) = taskDao.delete(task)

    suspend fun incrementCompletedPomodoros(taskId: Long) =
        taskDao.incrementCompletedPomodoros(taskId)

    suspend fun deleteAllTasks() = taskDao.deleteAll()

    // Network operations
    suspend fun fetchMotivationalQuote(): Result<QuoteDto> =
        NetworkDataSource.fetchMotivationalQuote()
}
