package com.yxyn.myfinalproject.viewmodel

sealed interface HistoryUiState {
    data object Loading : HistoryUiState
    data class Success(
        val sessions: List<SessionDisplayItem>,
        val totalWorkMinutes: Int,
        val totalSessions: Int,
        val todaySessions: Int
    ) : HistoryUiState
    data object Empty : HistoryUiState
}

data class SessionDisplayItem(
    val id: Long,
    val type: String,
    val typeLabel: String,
    val durationSeconds: Int,
    val startTime: Long,
    val endTime: Long,
    val isCompleted: Boolean,
    val taskTitle: String?,
    val note: String
)
