package com.yxyn.myfinalproject.datastore

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "user_preferences")

class UserPreferencesRepository(private val context: Context) {

    companion object {
        val WORK_DURATION = intPreferencesKey("work_duration")
        val SHORT_BREAK_DURATION = intPreferencesKey("short_break_duration")
        val LONG_BREAK_DURATION = intPreferencesKey("long_break_duration")
        val LONG_BREAK_INTERVAL = intPreferencesKey("long_break_interval")
        val AUTO_START_BREAK = intPreferencesKey("auto_start_break")
        val AUTO_START_WORK = intPreferencesKey("auto_start_work")
        val CURRENT_TASK_ID = longPreferencesKey("current_task_id")

        const val DEFAULT_WORK_DURATION = 25
        const val DEFAULT_SHORT_BREAK_DURATION = 5
        const val DEFAULT_LONG_BREAK_DURATION = 15
        const val DEFAULT_LONG_BREAK_INTERVAL = 4
    }

    val workDuration: Flow<Int> = context.dataStore.data.map { prefs ->
        prefs[WORK_DURATION] ?: DEFAULT_WORK_DURATION
    }

    val shortBreakDuration: Flow<Int> = context.dataStore.data.map { prefs ->
        prefs[SHORT_BREAK_DURATION] ?: DEFAULT_SHORT_BREAK_DURATION
    }

    val longBreakDuration: Flow<Int> = context.dataStore.data.map { prefs ->
        prefs[LONG_BREAK_DURATION] ?: DEFAULT_LONG_BREAK_DURATION
    }

    val longBreakInterval: Flow<Int> = context.dataStore.data.map { prefs ->
        prefs[LONG_BREAK_INTERVAL] ?: DEFAULT_LONG_BREAK_INTERVAL
    }

    val autoStartBreak: Flow<Boolean> = context.dataStore.data.map { prefs ->
        prefs[AUTO_START_BREAK]?.let { it == 1 } ?: false
    }

    val autoStartWork: Flow<Boolean> = context.dataStore.data.map { prefs ->
        prefs[AUTO_START_WORK]?.let { it == 1 } ?: false
    }

    val currentTaskId: Flow<Long?> = context.dataStore.data.map { prefs ->
        prefs[CURRENT_TASK_ID]?.let { if (it == -1L) null else it }
    }

    suspend fun setWorkDuration(minutes: Int) {
        context.dataStore.edit { prefs ->
            prefs[WORK_DURATION] = minutes
        }
    }

    suspend fun setShortBreakDuration(minutes: Int) {
        context.dataStore.edit { prefs ->
            prefs[SHORT_BREAK_DURATION] = minutes
        }
    }

    suspend fun setLongBreakDuration(minutes: Int) {
        context.dataStore.edit { prefs ->
            prefs[LONG_BREAK_DURATION] = minutes
        }
    }

    suspend fun setLongBreakInterval(count: Int) {
        context.dataStore.edit { prefs ->
            prefs[LONG_BREAK_INTERVAL] = count
        }
    }

    suspend fun setAutoStartBreak(enabled: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[AUTO_START_BREAK] = if (enabled) 1 else 0
        }
    }

    suspend fun setAutoStartWork(enabled: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[AUTO_START_WORK] = if (enabled) 1 else 0
        }
    }

    suspend fun setCurrentTaskId(taskId: Long?) {
        context.dataStore.edit { prefs ->
            prefs[CURRENT_TASK_ID] = taskId ?: -1L
        }
    }
}
