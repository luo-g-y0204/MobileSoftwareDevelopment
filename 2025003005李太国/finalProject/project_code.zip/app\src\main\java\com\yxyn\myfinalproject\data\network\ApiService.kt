package com.yxyn.myfinalproject.data.network

import retrofit2.http.GET

interface ApiService {

    @GET("random")
    suspend fun getRandomQuote(): List<QuoteDto>

    @GET("random?tags=motivational|productivity")
    suspend fun getMotivationalQuote(): List<QuoteDto>
}
