package com.yxyn.myfinalproject.data.network

import com.google.gson.annotations.SerializedName

data class QuoteDto(
    @SerializedName("_id")
    val id: String,
    @SerializedName("content")
    val content: String,
    @SerializedName("author")
    val author: String,
    @SerializedName("authorSlug")
    val authorSlug: String = "",
    @SerializedName("length")
    val length: Int = 0,
    @SerializedName("tags")
    val tags: List<String> = emptyList()
)
