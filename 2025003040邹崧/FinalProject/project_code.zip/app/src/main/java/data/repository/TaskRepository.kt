package com.zousong.finalproject.data.repository

import com.zousong.finalproject.data.dao.CategoryDao
import com.zousong.finalproject.data.dao.TaskDao
import com.zousong.finalproject.data.entity.Category
import com.zousong.finalproject.data.entity.Task
import com.zousong.finalproject.data.network.RetrofitInstance
import com.zousong.finalproject.data.network.dto.QuoteDto
import kotlinx.coroutines.flow.Flow

class TaskRepository(
    private val taskDao: TaskDao,
    private val categoryDao: CategoryDao
) {
    suspend fun insertTask(task: Task) = taskDao.insertTask(task)
    suspend fun updateTask(task: Task) = taskDao.updateTask(task)
    suspend fun deleteTask(id: Int) = taskDao.deleteTask(id)
    fun getAllTasks(): Flow<List<Task>> = taskDao.getAllTasks()
    fun getTasksByCategory(categoryId: Int): Flow<List<Task>> = taskDao.getTasksByCategory(categoryId)
    fun searchTasks(query: String): Flow<List<Task>> = taskDao.searchTasks(query)
    fun getPendingCount(): Flow<Int> = taskDao.getPendingCount()

    suspend fun insertCategory(category: Category) = categoryDao.insertCategory(category)
    suspend fun deleteCategory(id: Int) = categoryDao.deleteCategory(id)
    fun getAllCategories(): Flow<List<Category>> = categoryDao.getAllCategories()

    suspend fun fetchRandomQuote(): Result<QuoteDto> {
        return try {
            val quote = RetrofitInstance.api.getRandomQuote()
            Result.success(quote)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}