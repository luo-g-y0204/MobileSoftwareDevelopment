package com.zousong.finalproject.data.network

import com.zousong.finalproject.data.network.dto.QuoteDto
import retrofit2.http.GET

interface ApiService {
    @GET("?c=a")  // 获取动画/漫画名言，也可省略参数使用默认
    suspend fun getRandomQuote(): QuoteDto
}