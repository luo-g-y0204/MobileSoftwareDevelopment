package com.zousong.finalproject.data.network.dto

data class QuoteDto(
    val hitokoto: String,   // 名言内容
    val from: String? = null // 出处（作者/来源）
)