package com.zousong.finalproject.viewmodel

import com.zousong.finalproject.data.entity.Task

sealed interface TaskListUiState {
    object Loading : TaskListUiState
    data class Success(val tasks: List<Task>, val pendingCount: Int) : TaskListUiState
    data class Error(val message: String) : TaskListUiState
}