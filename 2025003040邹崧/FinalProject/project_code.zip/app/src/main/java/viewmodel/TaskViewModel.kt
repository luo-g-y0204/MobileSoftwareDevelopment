package com.zousong.finalproject.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.zousong.finalproject.data.entity.Category
import com.zousong.finalproject.data.entity.Task
import com.zousong.finalproject.data.repository.TaskRepository
import com.zousong.finalproject.datastore.UserPreferencesRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class TaskViewModel(
    private val repository: TaskRepository,
    private val preferencesRepo: UserPreferencesRepository
) : ViewModel() {

    // ---------- UI 状态 ----------
    private val _uiState = MutableStateFlow<TaskListUiState>(TaskListUiState.Loading)
    val uiState: StateFlow<TaskListUiState> = _uiState.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedCategoryId = MutableStateFlow<Int?>(null)
    val selectedCategoryId: StateFlow<Int?> = _selectedCategoryId.asStateFlow()

    val showCompleted: StateFlow<Boolean> = preferencesRepo.showCompleted
        .stateIn(viewModelScope, SharingStarted.Eagerly, true)

    // ---------- 名言 ----------
    private val _quote = MutableStateFlow("点击刷新获取名言")
    val quote: StateFlow<String> = _quote.asStateFlow()

    private val _isQuoteLoading = MutableStateFlow(false)
    val isQuoteLoading: StateFlow<Boolean> = _isQuoteLoading.asStateFlow()

    // ---------- 分类列表 ----------
    private val _categories = MutableStateFlow<List<Category>>(emptyList())
    val categories: StateFlow<List<Category>> = _categories.asStateFlow()

    init {
        loadTasks()
        loadQuote()
        loadCategories()   // 加载分类
    }

    // ---------- 加载任务 ----------
    private fun loadTasks() {
        viewModelScope.launch {
            _uiState.value = TaskListUiState.Loading
            combine(
                repository.getAllTasks(),
                _selectedCategoryId,
                _searchQuery.debounce(300),
                showCompleted
            ) { allTasks, categoryId, query, showCompleted ->
                var filtered = allTasks
                if (!showCompleted) {
                    filtered = filtered.filter { !it.isCompleted }
                }
                categoryId?.let { id ->
                    filtered = filtered.filter { it.categoryId == id }
                }
                if (query.isNotBlank()) {
                    filtered = filtered.filter { task ->
                        task.title.contains(query, ignoreCase = true) ||
                                (task.description?.contains(query, ignoreCase = true) == true)
                    }
                }
                filtered.sortedByDescending { it.createdAt }
            }.collect { filteredTasks ->
                val pending = repository.getPendingCount().first()
                _uiState.value = TaskListUiState.Success(filteredTasks, pending)
            }
        }
    }

    // ---------- 加载分类 ----------
    private fun loadCategories() {
        viewModelScope.launch {
            repository.getAllCategories().collect { list ->
                _categories.value = list
            }
        }
    }

    // ---------- 其他方法 ----------
    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setSelectedCategory(categoryId: Int?) {
        _selectedCategoryId.value = categoryId
    }

    suspend fun toggleShowCompleted() {
        preferencesRepo.setShowCompleted(!showCompleted.value)
    }

    fun insertTask(task: Task) = viewModelScope.launch {
        repository.insertTask(task)
    }

    fun updateTask(task: Task) = viewModelScope.launch {
        repository.updateTask(task)
    }

    fun deleteTask(id: Int) = viewModelScope.launch {
        repository.deleteTask(id)
    }

    // ---------- 名言 ----------
    private fun loadQuote() {
        viewModelScope.launch {
            preferencesRepo.lastQuote.collect { quote ->
                if (quote == "点击刷新获取名言") {
                    refreshQuote()
                } else {
                    _quote.value = quote
                }
            }
        }
    }

    fun refreshQuote() {
        viewModelScope.launch {
            _isQuoteLoading.value = true
            val result = repository.fetchRandomQuote()
            _isQuoteLoading.value = false
            result.onSuccess { dto ->
                val text = "${dto.hitokoto} — ${dto.from ?: "佚名"}"
                _quote.value = text
                preferencesRepo.saveLastQuote(text)
            }.onFailure {
                _quote.value = "获取名言失败，请稍后重试"
            }
        }
    }

    // ---------- 分类管理（可选） ----------
    fun insertCategory(category: Category) = viewModelScope.launch {
        repository.insertCategory(category)
    }
}