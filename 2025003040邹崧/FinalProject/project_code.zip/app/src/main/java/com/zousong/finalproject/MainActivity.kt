package com.zousong.finalproject

import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.ui.Modifier
import com.zousong.finalproject.data.database.AppDatabase
import com.zousong.finalproject.data.entity.Category
import com.zousong.finalproject.data.repository.TaskRepository
import com.zousong.finalproject.datastore.UserPreferencesRepository
import com.zousong.finalproject.navigation.AppNavigation
import com.zousong.finalproject.ui.theme.MyTodoTheme
import com.zousong.finalproject.viewmodel.TaskViewModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        try {
            val database = AppDatabase.getInstance(this)
            val taskDao = database.taskDao()
            val categoryDao = database.categoryDao()

            // 插入默认分类（如果为空）
            CoroutineScope(Dispatchers.IO).launch {
                val categories = categoryDao.getAllCategories().firstOrNull()
                if (categories.isNullOrEmpty()) {
                    categoryDao.insertCategory(Category(name = "工作", color = 0xFF2196F3.toInt()))
                    categoryDao.insertCategory(Category(name = "学习", color = 0xFF4CAF50.toInt()))
                    categoryDao.insertCategory(Category(name = "生活", color = 0xFFFF9800.toInt()))
                }
            }

            val taskRepository = TaskRepository(taskDao, categoryDao)
            val preferencesRepository = UserPreferencesRepository(this)
            val viewModel = TaskViewModel(taskRepository, preferencesRepository)

            setContent {
                MyTodoTheme {
                    Surface(
                        modifier = Modifier.fillMaxSize(),
                        color = MaterialTheme.colorScheme.background
                    ) {
                        AppNavigation(viewModel = viewModel)
                    }
                }
            }
        } catch (e: Exception) {
            Log.e("MainActivity", "启动失败", e)
            setContent {
                Surface(modifier = Modifier.fillMaxSize()) {
                    Text("启动失败: ${e.message}")
                }
            }
        }
    }
}