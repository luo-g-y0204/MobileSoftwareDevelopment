package com.zousong.finalproject.datastore

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore("user_prefs")

class UserPreferencesRepository(context: Context) {
    private val dataStore = context.dataStore

    companion object {
        val SHOW_COMPLETED = booleanPreferencesKey("show_completed")
        val LAST_QUOTE = stringPreferencesKey("last_quote")
    }

    val showCompleted: Flow<Boolean> = dataStore.data
        .map { prefs -> prefs[SHOW_COMPLETED] ?: true }
        .catch { emit(true) }  // 如果读取失败，默认返回 true

    suspend fun setShowCompleted(show: Boolean) {
        try {
            dataStore.edit { prefs ->
                prefs[SHOW_COMPLETED] = show
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    val lastQuote: Flow<String> = dataStore.data
        .map { prefs -> prefs[LAST_QUOTE] ?: "点击刷新获取名言" }
        .catch { emit("点击刷新获取名言") }

    suspend fun saveLastQuote(quote: String) {
        try {
            dataStore.edit { prefs ->
                prefs[LAST_QUOTE] = quote
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}