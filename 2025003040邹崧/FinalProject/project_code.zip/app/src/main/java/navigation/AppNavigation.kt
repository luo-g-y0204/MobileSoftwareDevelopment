package com.zousong.finalproject.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.zousong.finalproject.ui.screens.*
import com.zousong.finalproject.viewmodel.TaskViewModel

sealed class Screen(val route: String) {
    object TaskList : Screen("task_list")
    object TaskDetail : Screen("task_detail/{taskId}") {
        fun passId(taskId: Int) = "task_detail/$taskId"
    }
    object TaskEdit : Screen("task_edit/{taskId}") {
        fun passId(taskId: Int) = "task_edit/$taskId"
    }
    object TaskAdd : Screen("task_add")  // 新增路由，不带参数
    object Settings : Screen("settings")
}

@Composable
fun AppNavigation(viewModel: TaskViewModel) {
    val navController = rememberNavController()

    NavHost(
        navController = navController,
        startDestination = Screen.TaskList.route
    ) {
        composable(Screen.TaskList.route) {
            TaskListScreen(navController, viewModel)
        }
        composable(
            route = Screen.TaskDetail.route,
            arguments = listOf(navArgument("taskId") { type = NavType.IntType })
        ) { backStackEntry ->
            val taskId = backStackEntry.arguments?.getInt("taskId") ?: 0
            TaskDetailScreen(taskId, navController, viewModel)
        }
        // 新增任务：不带参数
        composable(Screen.TaskAdd.route) {
            TaskEditScreen(taskId = null, navController, viewModel)
        }
        // 编辑任务：带 taskId 参数
        composable(
            route = Screen.TaskEdit.route,
            arguments = listOf(navArgument("taskId") { type = NavType.IntType })
        ) { backStackEntry ->
            val taskId = backStackEntry.arguments?.getInt("taskId") ?: 0
            TaskEditScreen(taskId = taskId, navController, viewModel)
        }
        composable(Screen.Settings.route) {
            SettingsScreen(viewModel)
        }
    }
}