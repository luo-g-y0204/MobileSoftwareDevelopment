plugins {
    id("com.android.application") apply false
    id("org.jetbrains.kotlin.android") apply false
}
allprojects {
    tasks.withType<org.jetbrains.kotlin.gradle.tasks.KotlinCompile>().configureEach {
        kotlinOptions {
            jvmTarget = "17"
        }
    }
}